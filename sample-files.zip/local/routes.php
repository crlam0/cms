<?php

return [
    'request-local' => [
        'pattern' => '^request\/[\w\-]+$',
        'controller' => 'local\RequestController',
    ],    

];

