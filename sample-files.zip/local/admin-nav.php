<!-- ================== MENU ================== -->
<?php

use Classes\App;

$items = [
    ['url' => '../', 'title' => 'На сайт', 'image' => 'admin_back.gif', 'flag' => ''],
    ['url' => '', 'title' => 'На Главную', 'image' => 'admin_banners.gif', 'flag' => ''],    
];

if(App::$routing->getRoute('catalog-part-edit')) {
    $items = array_merge($items, [ 
        ['url' => 'catalog-edit/', 'title' => 'Каталог', 'image' => 'admin_cat.gif', 'flag' => ''],
        ['url' => 'items-props-edit/', 'title' => 'Прайс-лист', 'image' => 'admin_cat.gif', 'flag' => ''],
        ['url' => 'discount-edit/', 'title' => 'Скидки', 'image' => 'admin_discount.gif', 'flag' => ''],
    ]);    
}

if(App::$routing->getRoute('blog-edit')) {
    $items = array_merge($items, [ 
        ['url' => 'blog-edit/', 'title' => 'Блог', 'image' => 'admin_news.gif', 'flag' => ''],
        ['url' => 'comments-edit/', 'title' => 'Комментарии', 'image' => 'admin_menu.png', 'flag' => ''],
    ]);    
}

if(App::$routing->getRoute('article-list-edit')) {
    $items = array_merge($items, [ 
        ['url' => 'article-edit/', 'title' => 'Статьи', 'image' => 'admin_text.gif', 'flag' => ''],
    ]);    
}

if(App::$routing->getRoute('gallery-list-edit')) {
    $items = array_merge($items, [ 
        ['url' => 'gallery-edit/', 'title' => 'Фотографии', 'image' => 'admin_banners.gif', 'flag' => ''],
    ]);    
}

if(App::$routing->getRoute('media-list-edit')) {
    $items = array_merge($items, [ 
        ['url' => 'media-edit/', 'title' => 'Файлы', 'image' => 'admin_files.gif', 'flag' => ''],
    ]);    
}

$items = array_merge($items, [ 
    ['url' => 'request-list/', 'title' => 'Заказы', 'image' => 'admin_request.gif', 'flag' => ''],
    ['url' => 'feedback-edit/', 'title' => 'Отзывы', 'image' => 'admin_users.gif', 'flag' => ''],
    ['url' => 'partners-edit/', 'title' => 'Партнеры', 'image' => 'admin_vacancy.gif', 'flag' => ''],
    ['url' => 'menu-edit/', 'title' => 'Меню', 'image' => 'admin_menu.png', 'flag' => ''],
    ['url' => 'view-stats', 'title' => 'Статистика', 'image' => 'admin_discount.gif', 'flag' => ''],
    ['url' => 'users-edit/', 'title' => 'Пользователи', 'image' => 'admin_users.gif', 'flag' => ''],
    ['url' => '../logout/', 'title' => 'Выход', 'image' => 'admin_exit.gif', 'flag' => ''],
    
    ['url' => 'templates-edit/', 'title' => 'Шаблоны', 'image' => '', 'flag' => 'global'],
    ['url' => 'settings-edit/', 'title' => 'Настройки', 'image' => '', 'flag' => 'global'],
    ['url' => 'messages-edit/', 'title' => 'Сообщения', 'image' => '', 'flag' => 'global'],
    ['url' => 'parts-edit/', 'title' => 'Разделы', 'image' => '', 'flag' => 'global'],
//    ['url' => 'slider-edit/', 'title' => 'Картинки в шапке', 'image' => '', 'flag' => 'global'],
    ['url' => 'cache-clear', 'title' => 'Очистка кэша', 'image' => '', 'flag' => 'global'],
    ['url' => 'gen-sitemap', 'title' => 'Генерация Sitemap', 'image' => '', 'flag' => 'global'],
]);

$content = '';

foreach ($items as $item) {
    if ((strlen($item['flag'])) && (!App::$user->haveFlag($item['flag']))) {
        continue;
    }
    $url = App::$SUBDIR . 'admin/' . $item['url'];
    if(strlen($item['image'])) {
        $content .=  '<div class="admin-menu-image"><a href="' . $url . '"><img src="' . App::$SUBDIR . 'admin/images/' . $item['image'] . '" border="0"><span>'. $item['title'] .'</span></a></div>' . PHP_EOL;
    } else {
        $content .=  '<div class="admin-menu-item"><a href="' . $url . '">'. $item['title'] .'</a></div>' . PHP_EOL;
    }
}

echo $content;
