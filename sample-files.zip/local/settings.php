<?php

return [
    'slider' => [
        'upload_path' => 'upload/slider/',
        'image_width' => 1140,
        'image_height' => 400,
    ],
    'news' => [
        'upload_path' => 'upload/',
        'image_width' => 512,
        'image_height' => 512,
    ],
    'offers' => [
        'upload_path' => 'upload/',
        'image_width' => 512,
        'image_height' => 512,
    ],
    'feedback' => [
        'upload_path' => 'upload/',
        'image_width' => 256,
        'image_height' => 256,
    ],
    'partners' => [
        'upload_path' => 'upload/',
        'image_width' => 320,
    ],
    'twig' => [
        'template_dirs' => [
            'templates',
        ],
    ],
    'modules' => [
        'admin' => [
            'bootstrap' => 'admin\Bootstrap',
        ],
        'article' => [
            'bootstrap' => 'modules\article\Bootstrap',
            'article_per_page' => 10,
            'list_upload_path' => 'upload/article/',
            'list_image_width' => 256,
            'list_image_height' => 256,
            'item_upload_path' => 'upload/article/',
            'item_image_width' => 256,
            'item_image_height' => 256,
        ],
        'blog' => [
            'bootstrap' => 'modules\blog\Bootstrap',
            'header' => 'Блог',
        ],
        'catalog' => [
            'bootstrap' => 'modules\catalog\Bootstrap',
            'header' => 'Каталог услуг',
            'part_image_width' => 190,
            'part_image_height' => 190,
            'item_image_width' => 1024,
            'item_image_height' => 768,
            'default_items_props' => '
{
 "special_offer": {
   "name": "Спец. предложение",
   "type": "boolean"
 },
 "novelty": {
   "name": "Новинка",
   "type": "boolean"
 },
 "not_availble": {
   "name": "Нет в наличии",
   "type": "boolean"
 }
}        
',
        ],
        'gallery' => [
            'bootstrap' => 'modules\gallery\Bootstrap',
        ],
        'media' => [
            'bootstrap' => 'modules\media\Bootstrap',
        ],
        'users' => [
            'bootstrap' => 'modules\users\Bootstrap',
            'signup_availbale' => true,
            'default_flags' => ['active', 'passwd'],
            'avatar_upload_path' => 'upload/avatars/',
            'avatar_image_width' => 128,
            'avatar_image_height' => 128,
        ],
    ],
]; 




