window.$ = window.jQuery = require('jquery');
require('bootstrap');
require('jquery.waitforimages');

require('./misc.js');

if (typeof window.DIR == "undefined") {
    var pathArray = window.location.pathname.split( '/' );
    var domain = pathArray[1];
    if(domain.match(/^[\w-.]+\.\w{1,5}$/)) {
        window.DIR = '/' + domain + '/';
    } else {
        window.DIR = '/';
    }
    // DIR = window.DIR;
};    

require('../../../include/js/popup.js');
