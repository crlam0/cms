function test() {
    if (confirm("Вы уверены ?")) {
        return true;
    } else {
        return false;
    }
}

$(function () {
    $('a[href*="#"]:not([href="#"])').click(function () {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html, body').animate({
                    scrollTop: target.offset().top
                }, 1000);
                return false;
            }
        }
    });
});


(function ($) {
    $('ul.nav li.have-submenu').hover(function () {
        $(this).find('.sub-menu').stop(true, true).delay(200).slideDown(500);
    }, function () {
        $(this).find('.sub-menu').stop(true, true).delay(200).slideUp(500);
    });
})(jQuery);


$('.custom-file-input').on('change', function() { 
   let fileName = $(this).val().split('\\').pop(); 
   $(this).next('.custom-file-label').addClass("selected").html(fileName); 
});

