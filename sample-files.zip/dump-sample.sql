-- MySQL dump 10.16  Distrib 10.2.36-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: boot_nsk_ru
-- ------------------------------------------------------
-- Server version	10.2.36-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article_item`
--

DROP TABLE IF EXISTS `article_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `date_add` datetime DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `list_id` int(11) DEFAULT NULL,
  `seo_alias` varchar(64) DEFAULT NULL,
  `date_change` datetime NOT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `uid` int(11) NOT NULL DEFAULT 0,
  `image_name` varchar(255) NOT NULL DEFAULT '',
  `image_type` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `seo_alias` (`seo_alias`),
  FULLTEXT KEY `Index_2` (`title`,`content`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_item`
--

LOCK TABLES `article_item` WRITE;
/*!40000 ALTER TABLE `article_item` DISABLE KEYS */;
INSERT INTO `article_item` VALUES (9,'About','<p>About this site</p>\r\n','2019-01-15 10:29:13','BooT',1,'main','2021-04-01 00:54:48','Y',7,'',''),(12,'Координаты','<p>This is my coords:&nbsp;https://github.com/crlam0</p>\r\n','2017-06-21 17:16:36','BooT',1,'coordinates','2021-04-01 01:40:45','Y',7,'',''),(23,'Товар 2','','2021-01-09 21:06:30','',6,'tovar_1','2021-01-09 21:28:18','Y',7,'tovar_2.jpg','image/jpeg'),(24,'Прибой','<p>\r\n	<img alt=\"\" src=\"[%SUBDIR%]upload/1_grib.jpg\" style=\"width: 300px; height: 400px;\" />куецеку</p>\r\n','2021-01-10 01:48:23','',6,'priboy','2021-02-01 20:59:10','Y',7,'','');
/*!40000 ALTER TABLE `article_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_list`
--

DROP TABLE IF EXISTS `article_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `descr` text DEFAULT NULL,
  `seo_alias` varchar(32) NOT NULL DEFAULT '',
  `date_change` datetime NOT NULL DEFAULT current_timestamp(),
  `uid` int(11) NOT NULL DEFAULT 0,
  `image_name` varchar(255) NOT NULL DEFAULT '',
  `image_type` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `seo_alias` (`seo_alias`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_list`
--

LOCK TABLES `article_list` WRITE;
/*!40000 ALTER TABLE `article_list` DISABLE KEYS */;
INSERT INTO `article_list` VALUES (1,'Разное','2009-05-13 14:41:56','<p>\r\n	Разное</p>\r\n','misc','2021-01-09 20:40:07',0,'','');
/*!40000 ALTER TABLE `article_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_posts`
--

DROP TABLE IF EXISTS `blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_add` datetime DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `seo_alias` varchar(64) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `target_type` varchar(16) NOT NULL DEFAULT 'article',
  `target_id` int(11) DEFAULT NULL,
  `href` varchar(255) DEFAULT NULL,
  `image_name` varchar(255) DEFAULT NULL,
  `image_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `seo_alias` (`seo_alias`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_posts`
--

LOCK TABLES `blog_posts` WRITE;
/*!40000 ALTER TABLE `blog_posts` DISABLE KEYS */;
INSERT INTO `blog_posts` VALUES (50,'2021-04-01 01:18:59',7,'Первая запись','first_post','<p>Первая запись</p>\r\n','Y','',0,NULL,'','');
/*!40000 ALTER TABLE `blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_posts_tags`
--

DROP TABLE IF EXISTS `blog_posts_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_posts_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_posts_tags`
--

LOCK TABLES `blog_posts_tags` WRITE;
/*!40000 ALTER TABLE `blog_posts_tags` DISABLE KEYS */;
INSERT INTO `blog_posts_tags` VALUES (24,50,19);
/*!40000 ALTER TABLE `blog_posts_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_tags`
--

DROP TABLE IF EXISTS `blog_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `seo_alias` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_tags`
--

LOCK TABLES `blog_tags` WRITE;
/*!40000 ALTER TABLE `blog_tags` DISABLE KEYS */;
INSERT INTO `blog_tags` VALUES (19,'Новости','novosti');
/*!40000 ALTER TABLE `blog_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_item`
--

DROP TABLE IF EXISTS `cat_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `part_id` int(10) unsigned NOT NULL DEFAULT 0,
  `num` int(3) DEFAULT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `b_code` varchar(45) DEFAULT '-',
  `title` varchar(255) NOT NULL DEFAULT '',
  `seo_alias` varchar(255) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `date_change` datetime DEFAULT NULL,
  `price` varchar(45) NOT NULL DEFAULT '0.00',
  `cnt_weight` varchar(32) DEFAULT NULL,
  `descr` text DEFAULT NULL,
  `descr_full` text DEFAULT NULL,
  `default_img` int(10) unsigned DEFAULT NULL,
  `css_class` varchar(50) NOT NULL DEFAULT '',
  `props` text DEFAULT NULL,
  `uid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `part_id` (`part_id`),
  KEY `seo_alias` (`seo_alias`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_item`
--

LOCK TABLES `cat_item` WRITE;
/*!40000 ALTER TABLE `cat_item` DISABLE KEYS */;
INSERT INTO `cat_item` VALUES (28,70,2,'Y','-','Товар 2','tovar_2','2021-04-01 01:01:08','2021-04-01 01:14:37','400','','','',61,'','{\"novelty\":\"true\"}',7),(29,70,1,'Y','-','Товар 1','tovar_1','2021-04-01 01:08:42','2021-04-01 01:14:55','1000','','','',NULL,'','{\"special_offer\":\"true\",\"not_availble\":\"true\"}',7);
/*!40000 ALTER TABLE `cat_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_item_images`
--

DROP TABLE IF EXISTS `cat_item_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_item_images` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL DEFAULT 0,
  `date_add` datetime DEFAULT NULL,
  `file_name` varchar(64) DEFAULT NULL,
  `descr` text DEFAULT NULL,
  `file_type` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_item_images`
--

LOCK TABLES `cat_item_images` WRITE;
/*!40000 ALTER TABLE `cat_item_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `cat_item_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_part`
--

DROP TABLE IF EXISTS `cat_part`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_part` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prev_id` int(10) unsigned NOT NULL DEFAULT 0,
  `num` int(3) DEFAULT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `title` varchar(255) NOT NULL DEFAULT '',
  `seo_alias` varchar(255) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `date_change` datetime DEFAULT NULL,
  `item_image_width` int(4) DEFAULT NULL,
  `item_image_height` int(4) DEFAULT NULL,
  `descr` text DEFAULT NULL,
  `image_name` varchar(255) DEFAULT '-',
  `image_type` varchar(32) DEFAULT NULL,
  `price_title` varchar(255) NOT NULL DEFAULT 'Цена, руб.',
  `items_props` text DEFAULT NULL,
  `related_products` text NOT NULL,
  `uid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `prev_id` (`prev_id`),
  KEY `seo_alias` (`seo_alias`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_part`
--

LOCK TABLES `cat_part` WRITE;
/*!40000 ALTER TABLE `cat_part` DISABLE KEYS */;
INSERT INTO `cat_part` VALUES (70,0,1,'Y','Раздел 1','part_1','2021-04-01 00:59:43','2021-04-01 01:13:51',1024,768,'','','','','{\r\n \"special_offer\": {\r\n   \"name\": \"Спец. предложение\",\r\n   \"type\": \"boolean\"\r\n },\r\n \"novelty\": {\r\n   \"name\": \"Новинка\",\r\n   \"type\": \"boolean\"\r\n },\r\n \"not_availble\": {\r\n   \"name\": \"Нет в наличии\",\r\n   \"type\": \"boolean\"\r\n }\r\n}        \r\n','',7);
/*!40000 ALTER TABLE `cat_part` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_type` varchar(16) NOT NULL DEFAULT 'blog',
  `target_id` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `email` varchar(32) DEFAULT NULL,
  `author` varchar(64) DEFAULT NULL,
  `ip` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `target_type` (`target_type`),
  KEY `target_id` (`target_id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (49,'gallery',21,'2021-04-01 01:52:28',7,'Test','Y','boot@ngs.ru','Игорь Краснов','::1'),(50,'blog',50,'2021-04-01 01:53:04',7,'Test1','Y','boot@ngs.ru','Игорь Краснов','::1');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount`
--

DROP TABLE IF EXISTS `discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discount` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `summ` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount`
--

LOCK TABLES `discount` WRITE;
/*!40000 ALTER TABLE `discount` DISABLE KEYS */;
INSERT INTO `discount` VALUES (1,0.00,0.00),(2,2000.00,3.00),(3,5000.00,5.00);
/*!40000 ALTER TABLE `discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `author` varchar(64) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `txt` text DEFAULT NULL,
  `ans` text DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `ans_uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `active` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `file_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gallery_images`
--

DROP TABLE IF EXISTS `gallery_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_id` int(11) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `date_change` datetime NOT NULL DEFAULT current_timestamp(),
  `uid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) DEFAULT NULL,
  `descr` text DEFAULT NULL,
  `file_name` varchar(64) DEFAULT NULL,
  `file_type` varchar(16) DEFAULT NULL,
  `view_count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `gallery_id` (`gallery_id`)
) ENGINE=MyISAM AUTO_INCREMENT=170 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery_images`
--

LOCK TABLES `gallery_images` WRITE;
/*!40000 ALTER TABLE `gallery_images` DISABLE KEYS */;
INSERT INTO `gallery_images` VALUES (169,21,'2021-04-01 01:42:47','2021-04-01 01:42:47',7,'Test 1','','test_1.jpg','image/jpeg',2);
/*!40000 ALTER TABLE `gallery_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gallery_list`
--

DROP TABLE IF EXISTS `gallery_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gallery_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_add` datetime DEFAULT NULL,
  `date_change` datetime NOT NULL DEFAULT current_timestamp(),
  `uid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) DEFAULT NULL,
  `descr` text DEFAULT NULL,
  `seo_alias` varchar(64) NOT NULL DEFAULT '',
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `default_image_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seo_alias` (`seo_alias`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery_list`
--

LOCK TABLES `gallery_list` WRITE;
/*!40000 ALTER TABLE `gallery_list` DISABLE KEYS */;
INSERT INTO `gallery_list` VALUES (21,'2021-04-01 01:42:30','2021-04-01 01:42:30',7,'New photo','','new_photo','Y',169);
/*!40000 ALTER TABLE `gallery_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_files`
--

DROP TABLE IF EXISTS `media_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `list_id` int(11) DEFAULT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `date_add` datetime DEFAULT NULL,
  `date_change` datetime NOT NULL DEFAULT current_timestamp(),
  `num` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `descr` text DEFAULT NULL,
  `download_count` int(255) NOT NULL DEFAULT 0,
  `uid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `list_id` (`list_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_files`
--

LOCK TABLES `media_files` WRITE;
/*!40000 ALTER TABLE `media_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_list`
--

DROP TABLE IF EXISTS `media_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `num` int(11) DEFAULT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `date_add` datetime DEFAULT NULL,
  `date_change` datetime NOT NULL DEFAULT current_timestamp(),
  `uid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) DEFAULT NULL,
  `seo_alias` varchar(128) DEFAULT NULL,
  `descr` text DEFAULT NULL,
  `image_name` varchar(255) NOT NULL DEFAULT '',
  `image_type` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `seo_alias` (`seo_alias`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_list`
--

LOCK TABLES `media_list` WRITE;
/*!40000 ALTER TABLE `media_list` DISABLE KEYS */;
INSERT INTO `media_list` VALUES (4,NULL,'Y','2021-04-01 01:38:13','2021-04-01 01:39:19',7,'Test 1','test_1','','',''),(5,NULL,'Y','2021-04-01 01:38:32','2021-04-01 01:38:32',7,'Test 2','test_2','','','');
/*!40000 ALTER TABLE `media_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_item`
--

DROP TABLE IF EXISTS `menu_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `text_id` int(11) NOT NULL DEFAULT 0,
  `flag` varchar(45) NOT NULL,
  `position` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `href` varchar(255) NOT NULL,
  `css_class` varchar(45) NOT NULL DEFAULT 'default',
  `active` int(1) NOT NULL DEFAULT 1,
  `submenu_id` int(11) NOT NULL DEFAULT 0,
  `menu_id` int(11) NOT NULL DEFAULT 0,
  `target_type` varchar(16) NOT NULL DEFAULT '',
  `target_id` int(11) DEFAULT NULL,
  `image_name` varchar(255) NOT NULL DEFAULT '',
  `image_type` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `active` (`active`),
  KEY `menu_id` (`menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_item`
--

LOCK TABLES `menu_item` WRITE;
/*!40000 ALTER TABLE `menu_item` DISABLE KEYS */;
INSERT INTO `menu_item` VALUES (18,0,'admin',32,'Адм. Раздел','admin/','dashboard',1,0,2,'',NULL,'',''),(57,0,'',1,'Test 1','','',1,0,8,'media_list',4,'',''),(24,0,'',10,'Фотографии','gallery/','photo',1,0,2,'',NULL,'',''),(28,0,'',20,'Файлы','media/','folder-o',1,8,2,'',0,'',''),(35,0,'',4,'Координаты','article/?view=12','compass',1,0,2,'article',12,'',''),(42,0,'',1,'Главная','','home',1,0,2,'',NULL,'',''),(38,0,'active',33,'Выход','logout/','sign-out',1,0,2,'',NULL,'',''),(47,0,'',7,'Блог','blog/','edit',1,0,2,'',NULL,'',''),(48,0,'passwd',31,'Сменить пароль','passwd-change/','gavel',1,0,2,'',NULL,'',''),(58,0,'',2,'Test 2','','sign-in',1,0,8,'media_list',5,'',''),(50,0,'',22,'Каталог','catalog/','shopping-cart',1,0,2,'',NULL,'',''),(52,0,'signup',35,'Регистрация','signup/','user-o',1,0,2,'',NULL,'',''),(53,0,'signup',34,'Войти','login/','sign-in',1,0,2,'',NULL,'',''),(54,0,'passwd',30,'Профиль','profile/','address-card-o',1,0,2,'',NULL,'','');
/*!40000 ALTER TABLE `menu_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_list`
--

DROP TABLE IF EXISTS `menu_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `root` int(1) NOT NULL DEFAULT 0,
  `title` varchar(255) DEFAULT NULL,
  `top_menu` int(1) NOT NULL DEFAULT 0,
  `bottom_menu` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_list`
--

LOCK TABLES `menu_list` WRITE;
/*!40000 ALTER TABLE `menu_list` DISABLE KEYS */;
INSERT INTO `menu_list` VALUES (2,1,'Главное',0,0),(8,0,'Файлы',0,0);
/*!40000 ALTER TABLE `menu_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` enum('info','notice','error','debug') NOT NULL DEFAULT 'info',
  `content` text DEFAULT NULL,
  `comment` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `title` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COMMENT='System messages';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (19,'sql_error','info','Произошла ошибка при обращении к базе данных ! Сообщение: \'[%error%]\'',NULL),(17,'user_login_failed','error','Ошибка авторизации! Введенные логин и пароль недоступны в системе !',NULL),(3,'file_not_found','error','Файл \'[%file_name%]\' не найден !',' '),(4,'script_fault','error','Ошибка выполнения скрипта !',' '),(5,'info','info',NULL,NULL),(6,'notice','notice',NULL,NULL),(7,'error','error',NULL,NULL),(8,'debug','info','',NULL),(9,'form_error_email','notice','Вы неверно ввели E-Mail адрес !',''),(10,'form_error_name','notice','Вы неверно ввели свое имя !',''),(11,'form_error_code','error','Неверный код подтверждения !',''),(12,'sql_field_eror','error','При заполнении формы вы использовали запрещенные символы !',''),(13,'tpl_not_found','error','Шаблон \'[%name%]\' не найден, возможно произошла внутренняя ошибка на сайте, приносим свои извинения.',''),(14,'block_not_found','error','Блок \'[%title%]\' не найден, возможно произошла внутренняя ошибка на сайте, приносим сови извинения.',''),(15,'default_tpl_not_found','error','Для данного раздела не найден шаблон по умолчанию, возможно произошла внутренняя ошибка на сайте, приносим свои извинения.',''),(16,'form_error_msg_too_short','notice','Вы не ввели сообщение, или оно слишком короткое !',''),(18,'user_already_logged_on','notice','Вы уже авторизованы в системе !',NULL),(20,'search_not_found','notice','Извините, по вашему запросу ничего не найдено.',NULL),(21,'vote_success','info','Спасибо, Ваш голос учтен.',NULL),(22,'vote_deny','notice','Вы уже голосовали !',NULL),(23,'rss_error','error','Невозможно считать ленту новостей.',NULL),(24,'list_empty','notice','Раздел пуст, приносим свои извинения.',NULL);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `file_name` varchar(50) DEFAULT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `seo_alias` varchar(255) DEFAULT NULL,
  `css_class` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `Index_2` (`author`,`title`,`content`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offers`
--

DROP TABLE IF EXISTS `offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offers` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `file_name` varchar(50) DEFAULT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `seo_alias` varchar(255) DEFAULT NULL,
  `css_class` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `Index_2` (`author`,`title`,`content`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offers`
--

LOCK TABLES `offers` WRITE;
/*!40000 ALTER TABLE `offers` DISABLE KEYS */;
/*!40000 ALTER TABLE `offers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partners`
--

DROP TABLE IF EXISTS `partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pos` int(3) NOT NULL DEFAULT 1,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `descr` text DEFAULT NULL,
  `file_name` varchar(128) DEFAULT NULL,
  `file_type` varchar(16) DEFAULT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partners`
--

LOCK TABLES `partners` WRITE;
/*!40000 ALTER TABLE `partners` DISABLE KEYS */;
/*!40000 ALTER TABLE `partners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parts`
--

DROP TABLE IF EXISTS `parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `user_flag` varchar(255) DEFAULT NULL,
  `tpl_name` varchar(255) DEFAULT 'default',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parts`
--

LOCK TABLES `parts` WRITE;
/*!40000 ALTER TABLE `parts` DISABLE KEYS */;
INSERT INTO `parts` VALUES (1,'Административный раздел','admin/','admin','admin'),(2,'default','','','default');
/*!40000 ALTER TABLE `parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phinxlog`
--

DROP TABLE IF EXISTS `phinxlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phinxlog`
--

LOCK TABLES `phinxlog` WRITE;
/*!40000 ALTER TABLE `phinxlog` DISABLE KEYS */;
INSERT INTO `phinxlog` VALUES (20181218092014,'CreateTestTable','2018-12-18 12:06:13','2018-12-18 12:06:13',0),(20190313183639,'AddReviewsTable','2019-10-20 21:48:33','2019-10-20 21:48:33',0),(20190320112509,'ChangeCatPartTable','2019-10-20 21:48:33','2019-10-20 21:48:33',0),(20191020214610,'AddTokenColumn','2019-10-20 21:48:33','2019-10-20 21:48:33',0),(20191108104345,'ChangeSettingsTemplatesColumns','2019-11-08 10:47:15','2019-11-08 10:47:15',0),(20191108184338,'ChangeUsersTable','2019-11-08 19:05:35','2019-11-08 19:05:35',0),(20191108225521,'ChangeMessagesTable','2019-11-08 22:56:26','2019-11-08 22:56:26',0),(20200226001240,'ChangeArticleItemTable','2020-11-04 03:37:46','2020-11-04 03:37:46',0),(20200928055740,'ChangePartnersTable','2020-11-07 16:33:08','2020-11-07 16:33:08',0),(20201107162035,'CreateTableBlogTags','2020-11-07 16:33:37','2020-11-07 16:33:37',0),(20201229232802,'CreateTableScoreLog','2020-12-29 16:57:30','2020-12-29 16:57:30',0),(20210109114819,'ChangeArticleTables','2021-01-09 06:40:07','2021-01-09 06:40:07',0),(20210109204035,'ChangeMenuItemTable','2021-01-09 13:41:43','2021-01-09 13:41:43',0),(20210131202604,'DropUnusedColumnsAndTables','2021-02-01 06:54:30','2021-02-01 06:54:30',0),(20210201003204,'ChangeGalleryTables','2021-02-01 06:54:30','2021-02-01 06:54:30',0),(20210201102444,'ChangeMediaTables','2021-02-01 06:54:30','2021-02-01 06:54:30',0),(20210202204915,'AddAciveColumnToCatalogTables','2021-03-30 22:40:30','2021-03-30 22:40:30',0),(20210203045041,'RenameCatItemImagesFnameColumn','2021-03-30 22:40:30','2021-03-30 22:40:30',0);
/*!40000 ALTER TABLE `phinxlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `contact_info` text NOT NULL,
  `active` enum('Y','N') DEFAULT 'Y',
  `item_list` text NOT NULL,
  `comment` text NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request`
--

LOCK TABLES `request` WRITE;
/*!40000 ALTER TABLE `request` DISABLE KEYS */;
/*!40000 ALTER TABLE `request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score_log`
--

DROP TABLE IF EXISTS `score_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `target_type` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `target_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `score` int(2) NOT NULL,
  `ip` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `target_type` (`target_type`),
  KEY `target_id` (`target_id`),
  KEY `uid` (`uid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_log`
--

LOCK TABLES `score_log` WRITE;
/*!40000 ALTER TABLE `score_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `score_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'faq_msg_per_page','20','<b>Сообщений на странице в форуме</b>'),(4,'base_keywords','','<b>Ключевые слова</b>'),(6,'debug','0','<b>Включен ли режим отладки</b>'),(10,'files_upload_path','upload/','Каталог для закачки файлов'),(14,'news_count','10','<b>Сколько новостей выводить</b>'),(15,'email_from_addr','boot@boot.nsk.ru','<b>С какого адреса посылать почту</b>'),(16,'site_title','Test project','<b>Название сайта</b>'),(19,'gallery_images_per_page','9','Изображений на странице'),(20,'gallery_max_width','650','Ширина изображений в галерее'),(21,'gallery_max_width_preview','200','Ширина изображений в галерее в предпросмотре'),(22,'gallery_upload_path','upload/gallery/','Каталог с изображениями'),(25,'stats_cookie_hours','720','Сколько времени хранить куку статистики'),(26,'media_upload_path','upload/media/','<b>Каталог для сохранения медиа файлов.</b>'),(27,'media_files_per_page','20','Количество файлов на страницу'),(30,'news_block_count','5','<b>Сколько новостей выводить в блоке</b>'),(32,'catalog_part_img_path','upload/cat_part/','Путь к картинкам для разделов каталога'),(33,'catalog_part_img_max_width','200','Максимальная ширина для картинок разделов.'),(34,'catalog_item_img_path','upload/cat_item/','Путь к картинкам для наименований каталога'),(35,'catalog_item_img_max_width','600','Максимальная ширина для картинок наименований.'),(37,'blog_msg_per_page','2','Количество постов на страницу в блоге'),(38,'email_to_addr','crlam0@cn.ru','<b>Почта админа</b>'),(39,'blog_img_path','upload/blog/','Каталог с картинками для блога'),(40,'gallery_fix_size','1','Обрезать фотографию до квадрата'),(42,'blog_img_max_width','150','Максимальная ширина заглавной картинки'),(43,'catalog_items_per_page','12','Количество наименований на странице'),(44,'site_description','Test project','<b>Описание сайта для поисковиков</b>'),(45,'sitemap_types','article;blog;gallery;catalog',''),(46,'gallery_icon_width','120','Ширина для иконок'),(47,'gallery_use_comments','1',''),(48,'catalog_item_img_preview','200',''),(49,'default_flags','signup','');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slider_images`
--

DROP TABLE IF EXISTS `slider_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slider_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `descr` text DEFAULT NULL,
  `file_name` varchar(64) DEFAULT NULL,
  `file_type` varchar(16) DEFAULT NULL,
  `pos` int(2) NOT NULL DEFAULT 1,
  `url` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slider_images`
--

LOCK TABLES `slider_images` WRITE;
/*!40000 ALTER TABLE `slider_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `slider_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templates`
--

DROP TABLE IF EXISTS `templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `do_parse` int(1) unsigned NOT NULL DEFAULT 1,
  `content` text DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `template_type` enum('my','twig') NOT NULL DEFAULT 'my',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=115 DEFAULT CHARSET=utf8 COMMENT='System templates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templates`
--

LOCK TABLES `templates` WRITE;
/*!40000 ALTER TABLE `templates` DISABLE KEYS */;
INSERT INTO `templates` VALUES (18,'news_table',1,'<div id=\"news\">\r\n[%loop_begin%]\r\n<div class=\"row\">\r\n  <div class=\"news_title\"><a href=\"[%SUBDIR%]news/[%row(seo_alias)%]/\" title=\"[%row(title)%]\">[%row(title)%]</a></div>\r\n  <div class=\"news_date\">[%row(date)%]</div>\r\n  <div class=\"row-content\">\r\n    <div class=\"news_image\"><img src=\"[%SUBDIR%]upload/news/[%row(file_name)%]\" class=\"img-responsive\" alt=\"[%row(title)%]\"/></div>\r\n    [%func(get_news_full_content)%]\r\n  </div>\r\n</div>\r\n[%loop_end%]\r\n</div>','<b>Страница с новостями</b>','news/','news_table','twig'),(46,'search_form',1,'<form action=[%PHP_SELF%] method=get>\r\n        <input type=hidden name=do_search value=1>\r\n        <table border=0 cellspacing=0 cellpadding=5 class=admin align=center>\r\n        <tr valign=middle bgcolor=#FFFFFF>\r\n<td>Искать:</td>\r\n<td><input type=edit maxlength=255 size=64 name=query_str value=\"[%query_str%]\"></td>\r\n<td><input type=submit value=\"  Ok  \"></td>\r\n</tr>\r\n</table>\r\n</form>\r\n','<b>Форма для поиска</b>','','','my'),(47,'search_results',1,'<h4>Результаты поиска:</h4>\r\n[%loop_begin%]\r\n<b>[%row(div_title)%] : </b> <a href=[%row(href)%][%row(id)%]>[%row(title)%]</a>\r\n<br>\r\n( <a href=[%row(href)%][%row(id)%]><font size=-2>[%BASE_HREF%][%row(href)%][%row(id)%]</font></a> )\r\n<br><br>\r\n[%loop_end%]\r\n<br>\r\n','<b>Результаты поиска</b>','','','my'),(25,'default',1,'','<b>Шаблон по умолчанию</b>','','main','twig'),(49,'faq_form',1,'<form action=[%SUBDIR%]faq/ method=\"POST\">    \r\n<input type=\"hidden\" name=\"added\" value=\"1\">\r\n<input type=\"hidden\" name=\"send_img_code\" value=\"1\">\r\n<input type=\"hidden\" name=\"CSRF_Token\" value=\"[%func(get_csrf_token)%]\">\r\n<div class=\"faq_form\">Сообщение :</div>\r\n<div>[%editor%]</div>\r\n<div class=\"faq_form\">Автор: </div><div class=\"faq_form\">\r\n	<input type=\"edit\" maxlength=64 class=\"form-control\" name=\"form[author]\" value=\"[%author%]\" required>\r\n</div>\r\n<div class=\"faq_form\">E-Mail: </div><div class=faq_form>\r\n	<input type=\"edit\" maxlength=128 class=\"form-control\" name=\"form[email]\" value=\"[%email%]\" required>\r\n</div>\r\n<div class=\"faq_form\"><img src=../include/image_code.php border=0 alt=\"Код подтверждения\"></div>\r\n<div class=\"faq_form\"><input type=\"edit\" class=\"form-control\" name=\"img_code\" maxlength=6 value=\"\" required></div>\r\n<div class=\"faq_form\"><input type=\"submit\" class=\"btn btn-primary\" value=\"Отправить\"></div>\r\n</form>\r\n<center><a href=[%SUBDIR%]faq/ class=\"btn btn-default\"> << Назад</a></center>','<b>Форма добавления в вопрос/овтет</b>','','faq_form','twig'),(48,'faq_list',1,'<div class=faq>\r\n[%pages_list%]\r\n[%loop_begin%]\r\n<div class=faq_author>[%row(author)%]</div>\r\n<div class=faq_date>[%row(date)%]</div>\r\n<div class=faq_txt>[%row(txt,nl2br)%]</div>\r\n[%row(ans,if,<div class=faq_ans>Ответ:</div><div class=faq_ans_txt>)%][%row(ans,nl2br)%]\r\n[%row(ans,if,</div>)%]\r\n<div class=separator></div>\r\n<br><br>\r\n[%loop_end%]\r\n[%pages_list%]\r\n<center>\r\n<a href=[%SUBDIR%]faq/?add=1 class=\"button btn btn-default\">Добавить</a>\r\n</center>\r\n</div>','<b>Список сообщений в вопрос/овтет</b>','','faq_list','twig'),(26,'block_news',1,'<div id=block_news>\r\n<div class=block_header>Новости</div>\r\n<div class=block_shadow></div>\r\n<div class=block_content>\r\n[%loop_begin%]\r\n<div class=news_title>[%row(title)%]</div>\r\n<div class=news_date>Дата:  [%row(date)%]</div>\r\n<div class=news_content>[%func(get_news_short_content)%]</div>\r\n<a href=[%SUBDIR%]news/index.php?show=[%row(id)%] class=news title=\"[%row(title)%]\">Подробнее >></a>\r\n[%loop_end%]\r\n<div align=center><a href=[%SUBDIR%]news/index.php class=button>Все новости</a></div>\r\n</div>\r\n<div class=block_end></div>\r\n</div>','<b>Шаблон для списка новостей</b>','','','my'),(27,'block_menu',1,'[%menu_content%]','<b>Главное меню</b>','','','my'),(30,'admin',1,'','Админский раздел','admin/','admin.html.twig','twig'),(40,'user_login_promt',1,'<div class=\"center-block\" align=\"center\">\r\n    <div align=\"center\" style=\"max-width: 400px;margin-top:30px;\">\r\n        <form action=\"{{ SUBDIR }}login/\" method=\"post\" name=\"login_form\">\r\n            <input type=hidden name=logon value=1>\r\n            <input type=\"edit\" name=\"login\" maxlength=\"32\" size=\"16\" class=\"form-control\" placeholder=\"Имя пользователя\" required autofocus>\r\n            <br />\r\n            <input type=\"password\" name=\"passwd\" maxlength=\"32\" size=\"16\" class=\"form-control\" placeholder=\"Пароль\" required>\r\n            <br />\r\n            <input type=\"checkbox\" name=\"rememberme\" maxlength=\"32\" size=\"16\" class=\"form-check-input\">\r\n            <label class=\"form-check-label\" for=\"rememberme\">Запомнить меня</label>\r\n            <br />\r\n            <br />\r\n            <input type=\"submit\" class=\"btn btn-primary\" value=\"   Войти   \">\r\n            <br />\r\n            <br />\r\n            <a href=\"{{ SUBDIR }}passwd_recovery/\">Восстановить пароль</a>\r\n        </form>\r\n    </div>\r\n</div>','Форма для логина','','user_login_promt','twig'),(86,'article_list',1,'<div id=\"articles_list\">\r\n    <div class=\"separator\"></div>\r\n    {% for row in rows %}\r\n        <div class=\"item_title\"><a href=\"{{ SUBDIR }}{{ get_article_list_href(null, row) }}\">{{ row.title }}</a></div>\r\n        <div class=\"item_descr\">{{ row.descr }}</div>\r\n        <div class=\"separator\"></div>\r\n    {% endfor %}\r\n</div>','<b>Разделы в статьях</b>','','article_list','twig'),(87,'article_items',1,'<div id=articles_list>\r\n<div class=separator></div>\r\n[%loop_begin%]\r\n<div class=item_title><a href=[%SUBDIR%][%func(get_article_href)%]>[%row(title)%]</a></div>\r\n<div class=item_descr>Автор: [%row(author)%]<br>Дата:  [%row(date_add)%]</div>\r\n<div class=separator></div>\r\n[%loop_end%]\r\n</div>','<b>Статьи в разделе</b>','','article_items','twig'),(57,'gallery_images_list',1,'{% if pager is defined %}\r\n    {% \r\n    include \'pager.html.twig\' with {\r\n        \'pager\': pager,\r\n        \'main_route\': gallery_list_href,\r\n        \'route\': gallery_list_href ~ \'{$page}/\'\r\n    }\r\n    %}\r\n{% endif %}\r\n<div id=\"gallery\"> \r\n    <center>\r\n        {% for row in rows %}\r\n            <div class=\"item col-xs-12 col-sm-6 col-lg-4\">\r\n                <div class=\"img_box_wrapper\">\r\n                    <div class=\"img_box\">\r\n                        <div class=img_content>{{ show_img(row) }}</div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"title\">{{ row.title }}</div>\r\n            </div>\r\n        {% endfor %}\r\n    </center>\r\n</div>\r\n{% if pager is defined %}\r\n    {% \r\n        include \'pager.html.twig\' with {\r\n            \'pager\': pager,\r\n            \'main_route\': gallery_list_href,\r\n            \'route\': gallery_list_href ~ \'{$page}/\'\r\n        }\r\n    %}\r\n{% endif %}\r\n<center><a href=\"{{ SUBDIR }}gallery/\" class=\"btn btn-default\"><<  Назад</a></center>','<b>Список изображений</b>','','gallery_images_list','twig'),(58,'gallery_image_view',1,'<center>\r\n    <div id=gallery>\r\n        <div class=view_image>\r\n            <img src=\"{{ SUBDIR }}{{ URL }}\" border=\"0\" id=\"popup_image\">\r\n        </div>\r\n        <br />\r\n        <div align=center>\r\n            {% if prev_id %}\r\n                <a class=\"btn btn-default gallery_button\" item_id=\"{{ prev_id }}\"><< Предыдущая</a>\r\n            {% endif %}\r\n            {% if next_id %}\r\n                <a class=\"btn btn-default gallery_button\" item_id=\"{{ next_id }}\">Следующая >></a>\r\n            {% endif %}\r\n        </div>\r\n    </div>\r\n</center>','<b>Просмотр изображения</b>','','gallery_image_view','twig'),(61,'gallery_part_list',1,'<div id=\"gallery\"> \r\n    {% for row in rows %}\r\n        <div class=\"row\">\r\n            <div class=\"image-icon col-xs-12 col-sm-3 col-lg-2\">\r\n                <a href=\"{{ SUBDIR }}{{ get_gallery_list_href(row.id) }}\" class=\"title\" title=\"[%row(title)%]\">\r\n                    {{ show_list_img(row) }}\r\n                </a>\r\n            </div>\r\n            <div class=\"list_descr col-xs-12 col-sm-8 col-lg-10\">\r\n                <div class=\"title\">\r\n                    <a href=\"{{ SUBDIR }}{{ get_gallery_list_href(row.id) }}\" class=\"title\" title=\"[%row(title)%]\">\r\n                        {{ row.title }}\r\n                    </a>\r\n                </div>\r\n                <div class=\"descr\">{{ row.descr }}</div>\r\n                <div class=\"img_count\">Добавлен: {{ row.date_add }}, Фотографий в разделе: {{ row.images }}</div>\r\n            </div>\r\n        </div>\r\n\r\n    {% endfor %}\r\n</div>\r\n','<b>Список разделов в галерее</b>','','gallery_part_list','twig'),(75,'media_part_list',1,'<div id=\"media\">\r\n    {% for row in rows %}\r\n        <div class=\"title\">\r\n            <a href=\"{{ SUBDIR }}{{ get_media_list_href(row.id) }}\" title=\"{{ row.title }}\">\r\n                {{ row.title }}\r\n            </a>\r\n        </div>\r\n        <div class=\"date\">Раздел добавлен: {{ row.date_add }}</div>\r\n        <div class=\"descr\">{{ row.descr }}</div>\r\n        <div class=\"img_count\">Файлов в разделе: {{ row.files }}</div>\r\n\r\n    {% endfor %}\r\n</div>\r\n\r\n','<b>Список разделов с файлами</b>','','media_part_list','twig'),(76,'media_files_list',1,'<div id=\"media\">\r\n    {% if list_descr|length > 0 %}\r\n        <div class=\"list_descr\">{{ list_descr }}</div>\r\n    {% endif %}\r\n    \r\n    {% for row in rows %}\r\n        <div class=\"title\">\r\n            {{ row.title }}\r\n        </div>\r\n	<div class=\"item_descr\">\r\n		<div class=\"preview\">{{ show_size(row) }} </div>\r\n		<div class=\"right_descr\">\r\n			<div class=\"descr\">{{ row.descr }}</div>\r\n			<div class=\"date\">Добавлен: {{ row.date_add }}</div>\r\n		</div>\r\n	</div>\r\n    {% endfor %}\r\n    \r\n    {% if pager is defined %}\r\n        {% \r\n        include \'pager.html.twig\' with {\r\n            \'pager\': pager,\r\n            \'main_route\': media_list_href,\r\n            \'route\': media_list_href ~ \'{$page}/\'\r\n        }\r\n        %}\r\n    {% endif %}\r\n\r\n    <center><a href={{ SUBDIR }}media/ class=\"btn btn-default\"><<  Назад</a></center>\r\n</div>\r\n','<b>Список файлов</b>','','media_files_list','twig'),(84,'article_view',1,'<div class=article_content>[%content%]</div>\r\n<div class=article_author>Автор: [%author%]</div>\r\n<div class=article_date>Дата: [%date_add%]</div>\r\n<div class=separator></div>','<b>Шаблон для просмотра статей</b>','','article_view','twig'),(93,'comments_list',1,'<a name=\"comments\"></a>\r\n<div id=\"comments\">\r\n                <div class=\"commented-section mt-2\">\r\n                    <div class=\"d-flex flex-row align-items-center commented-user\">\r\n                        <h5 class=\"mr-2\">Makhaya andrew</h5><span class=\"dot mb-1\"></span><span class=\"mb-1 ml-2\">10 hours ago</span>\r\n                    </div>\r\n                    <div class=\"comment-text-sm\"><span>Nunc sed id semper risus in hendrerit gravida rutrum. Non odio euismod lacinia at quis risus sed. Commodo ullamcorper a lacus vestibulum sed arcu non odio euismod. Enim facilisis gravida neque convallis a. In mollis nunc sed id. Adipiscing elit pellentesque habitant morbi tristique senectus et netus. Ultrices mi tempus imperdiet nulla malesuada pellentesque.</span></div>\r\n                    <div class=\"reply-section\">\r\n                        <div class=\"d-flex flex-row align-items-center voting-icons\"><i class=\"fa fa-sort-up fa-2x mt-3 hit-voting\"></i><i class=\"fa fa-sort-down fa-2x mb-3 hit-voting\"></i><span class=\"ml-2\">25</span><span class=\"dot ml-2\"></span>\r\n                            <h6 class=\"ml-2 mt-1\">Reply</h6>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n[%loop_begin%]\r\n<div class=\"wrapper\">\r\n<div class=\"author\">[%row(author)%]</div>\r\n<div class=\"date\">[%row(date_add)%]</div>\r\n<div class=\"content\">[%row(content,nl2br)%]</div>\r\n</div>\r\n[%loop_end%]\r\n</div>','<b>Список комментариев</b>','','comments_list','twig'),(92,'comment_add_form',1,'<a name=\"comment_form\"></a>\r\n<form action=\"[%action%]\" method=\"POST\">    \r\n<input type=\"hidden\" name=\"form[add_comment]\" value=\"1\">\r\n<input type=\"hidden\" name=\"send_img_code\" value=\"1\">\r\n<input type=\"hidden\" name=\"CSRF_Token\" value=\"[%func(get_csrf_token)%]\">\r\n<div class=\"comment_add_form\"><b>Комментарий :</b></div>\r\n<div>[%editor%]</div>\r\n<div class=\"comment_form\">Автор: </div><div class=\"comment_form\">\r\n	<input type=\"edit\" maxlength=64 class=\"form-control\" name=\"form[author]\" value=\"[%author%]\" required>\r\n</div>\r\n<div class=\"comment_form\">E-Mail: </div><div class=comment_form>\r\n	<input type=\"edit\" maxlength=128 class=\"form-control\" name=\"form[email]\" value=\"[%email%]\" required>\r\n</div>\r\n<div class=\"comment_form\"><img src=\"[%SUBDIR%]include/image_code.php\" border=0 alt=\"Код подтверждения\"></div>\r\n<div class=\"comment_form\"><input type=\"edit\" class=\"form-control\" name=\"form[img_code]\" maxlength=6 value=\"\" required></div>\r\n<div class=\"comment_form\"><input type=\"submit\" class=\"btn btn-primary\" value=\"Отправить\"></div>\r\n</form>','<b>Форма добавления коментария</b>','','comment_add_form','twig'),(96,'user_passwd_change',1,'<div class=\"center-block\" align=\"center\">\r\n<div align=\"center\" style=\"max-width: 400px;margin-top:30px;\">\r\n<form action=\"[%SUBDIR%]passwd_change/\" method=\"post\" name=\"passwd_change_form\">\r\n\r\n<input type=\"hidden\" name=\"passwd_change\" value=\"1\">\r\n\r\n<input type=\"password\" name=\"old_passwd\" class=\"form-control\" placeholder=\"Старый пароль\" required autofocus>\r\n<br />\r\n<input type=\"password\" name=\"new_passwd1\" class=\"form-control\" placeholder=\"Новый пароль\" required>\r\n<br />\r\n<input type=\"password\" name=\"new_passwd2\" class=\"form-control\" placeholder=\"Повтор нового пароля\" required>\r\n<br />\r\n<input type=\"submit\" class=\"btn btn-primary\" value=\"   Сменить   \">\r\n\r\n</form>\r\n</div>\r\n</div>','Форма смены пароля','','user_passwd_change','twig'),(102,'blog_posts',1,'<div id=\"blog\">\r\n    \r\n{% for row in rows %}\r\n    <div class=\"card card-default\">\r\n        <div class=\"post_title card-heading\">\r\n		<div class=\"\">\r\n		   <a href=\"{{ SUBDIR }}{{ get_post_href(null,row) }}\" title=\"{{ row.title }}\">{{ row.title }}</a>\r\n		</div>\r\n	        <div class=\"post_author\">\r\n        	   {{ row.author }}\r\n	           <span class=post_date>{{ row.date_add }}</span>\r\n	        </div>\r\n	</div>\r\n        <div class=\"card-body\">{{ get_post_content(row)|raw }}</div>\r\n        <div class=\"card-footer\">\r\n            [ <a href=\"{{ SUBDIR }}{{ get_post_href(null,row) }}#comment_form\" title=\"{{ row.title }}\">Добавить комментарий</a> ]\r\n            [ <a href=\"{{ SUBDIR }}{{ get_post_href(null,row) }}#comments\" title=\"{{ row.title }}\">\r\n                Комментариев: {{ get_post_comments_count(row) }}</a> ]\r\n        </div>\r\n    </div>\r\n    <br />\r\n{% endfor %}\r\n\r\n{% if pager is defined %}\r\n    {% \r\n        include \'pager.html.twig\' with {\r\n            \'pager\': pager,\r\n            \'main_route\': \'blog/\',\r\n            \'route\': \'blog/page{$page}/\',\r\n        }\r\n    %}\r\n{% endif %}\r\n\r\n</div>\r\n','<b>Посты в Блоге</b>','','blog_posts','twig'),(106,'cat_item_list',1,'{% if part_descr is defined %}\r\n    <div class=\"part_descr\">{{ part_descr }}</div>\r\n{% endif %}\r\n\r\n{% if cat_part_href is not defined %}\r\n    {% set various_cat_part_href = true %}\r\n{% endif %}\r\n\r\n\r\n<div id=\"cat_items\">\r\n    {% for row in rows %}\r\n        {% set props = get_props_array(row.props) %}\r\n        {% if various_cat_part_href is defined %}\r\n            {% set cat_part_href = get_cat_part_href(row.part_id) %}\r\n        {% endif %}\r\n        \r\n        <div class=\"cat_item\">\r\n            <div class=\"cat_item_image_border\">\r\n                <div class=\"cat_item_image_table\">\r\n                    <div class=\"cat_item_image\" item_id=\"{{ row.item_id }}\">\r\n                        {% set image = get_item_image_filename(row.fname) %}\r\n                        <a href=\"{{ SUBDIR }}{{ cat_part_href }}{{ row.seo_alias }}\" title=\"{{ row.title }}\">\r\n                        {% if image %}\r\n                            <img src=\"{{ SUBDIR }}{{ image }}\" alt=\"{{ row.title }}\">\r\n                        {% else %}\r\n                            Изображение отсутствует\r\n                        {% endif %}    \r\n                        </a>\r\n                    </div>\r\n                </div>\r\n                {% if props.special_offer is defined %}\r\n                    <div class=\"cat_item_special_offer\">Хит</div>\r\n                {% endif %}\r\n                {% if props.novelty is defined %}\r\n                    <div class=\"cat_item_novelty\">Новинка</div>\r\n                {% endif %}\r\n            </div>\r\n            <div class=\"cat_item_title\">\r\n                <a href=\"{{ SUBDIR }}{{ cat_part_href }}{{ row.seo_alias }}\" title=\"{{ row.title }}\">{{ row.title }}</a>\r\n            </div>\r\n            <div class=\"cat_item_descr\"><i>{{ row.descr }}</i></div>\r\n            <div class=\"cat_item_price\">\r\n                {% if row.price %}\r\n                    Цена: {{ row.price }}\r\n                {% endif %}\r\n            </div>\r\n            <div class=cat_item_buy>\r\n                <input type=hidden class=\"cnt_{{ row.id }}\" size=\"1\" maxlength=\"2\" value=\"1\">\r\n                <a class=\"buy_button btn btn-default\" item_id=\"{{ row.item_id }}\">В корзину</a>\r\n            </div>\r\n        </div>\r\n\r\n    {% endfor %}\r\n\r\n    {% if pager is defined %}\r\n        {% \r\n        include \'pager.html.twig\' with {\r\n            \'pager\': pager,\r\n            \'main_route\': cat_part_href,\r\n            \'route\': cat_part_href ~ \'page{$page}/\'\r\n        }\r\n        %}\r\n    {% endif %}\r\n\r\n</div>\r\n    \r\n    ','<b>Просмотр позиций в каталоге</b>','','cat_item_list','twig'),(107,'cat_item_view',1,'{% set props = get_props_array(props) %}\r\n\r\n\r\n<div id=\"cat_item_view\">\r\n    <div class=\"image_block\">\r\n        <div class=\"cat_item_image_border\">\r\n            <div class=\"cat_item_image_table\">\r\n                <div class=\"cat_item_image cat_item_image_popup\">\r\n                    {% set image = get_item_image_filename(fname) %}\r\n                    {% if image %}\r\n                        <img src=\"{{SUBDIR}}{{image}}\" alt=\"{{title}}\" file_name=\"{{fname}}\" item_id=\"{{id}}\" image_id=\"{{cat_item_images_id}}\" border=\"0\" align=\"left\" class=\"cat_item_image_popup\">\r\n                    {% else %}\r\n                        Изображение отсутствует\r\n                    {% endif %}\r\n                </div>\r\n            </div>\r\n            {% if props.special_offer is defined %}\r\n                <div class=\"cat_item_special_offer\">Хит</div>\r\n            {% endif %}\r\n            {% if props.novelty is defined %}\r\n                <div class=\"cat_item_novelty\">Новинка</div>\r\n            {% endif %}\r\n        </div>\r\n        {% if images is defined %}\r\n            <div style=\"width:100%;height:1px;float:left;\"> </div>\r\n            <div class=item_images>\r\n                {% for image in images %}\r\n                    {% set image_file = get_item_image_filename(image.fname, 50) %}\r\n                    {% if image_file %}\r\n                        <div class=\"image_item\"><img class=\"cat_images\" src=\"{{SUBDIR}}{{image_file}}\" item_id=\"{{id}}\" file_name=\"{{image.fname}}\" image_id=\"{{image.id}}\" border=\"0\"></div>\r\n                    {% endif %}\r\n                {% endfor %}\r\n            </div>\r\n        {% endif %}\r\n    </div>	\r\n    <div class=\"price\">\r\n        <span>\r\n            {% if props.price1 is not defined and props.price2 is not defined %}\r\n                Цена: {{ price }}<br />\r\n            {% else %}\r\n                {% if props.price1 is defined %}\r\n                    {{ get_prop_name(part_id,\'price1\') }}: {{ props.price1 }} <br />\r\n                {% endif %}\r\n                {% if props.price2 is defined %}\r\n                    {{ get_prop_name(part_id,\'price2\') }}: {{ props.price2 }} <br />\r\n                {% endif %}\r\n            {% endif %}\r\n            \r\n            {% if props.balance_01 is not defined and props.balance_02 is not defined %}\r\n                <span class=\"balance\">Под заказ</span><br />\r\n            {% else %}\r\n                {% if props.balance_01 is defined %}\r\n                    <span class=\"balance\">{{ get_prop_name(part_id,\'balance_01\') }}: {{ props.balance_01 }} </span><br />\r\n                {% endif %}\r\n                {% if props.balance_02 is defined %}\r\n                    <span class=\"balance\">{{ get_prop_name(part_id,\'balance_02\') }}: {{ props.balance_02 }} </span><br />\r\n                {% endif %}\r\n            {% endif %}\r\n            \r\n            {% if props.balance_01_used is not defined and props.balance_02_used is not defined %}\r\n                <span class=\"balance\"></span><br />\r\n            {% else %}\r\n                {% if props.balance_01_used is defined %}\r\n                    <span class=\"used_balance\">{{ get_prop_name(part_id,\'balance_01_used\') }}: {{ props.balance_01_used }} </span><br />\r\n                {% endif %}\r\n                {% if props.balance_02_used is defined %}\r\n                    <span class=\"used_balance\">{{ get_prop_name(part_id,\'balance_02_used\') }}: {{ props.balance_02_used }} </span><br />\r\n                {% endif %}\r\n            {% endif %}\r\n            \r\n        </span>\r\n        <input type=\"hidden\" class=\"cnt_{{ id }}\" size=1 maxlength=2 value=1>\r\n        <a class=\"buy_button btn btn-default\" item_id=\"{{ id }}\">В корзину</a>\r\n    </div>\r\n    <div class=\"row\"> </div>\r\n    <div class=\"descr\">\r\n        {{ descr_full }}\r\n    </div>\r\n</div>\r\n    \r\n{% if related_products is defined %}\r\n    <div id=\"related_products\">\r\n        <h4>С этим товаром обычно покупают:</h4>\r\n        {{ related_products }}\r\n    </div>\r\n{% endif %}\r\n\r\n{% if page is not defined %}\r\n    {% set page = \'\' %}\r\n{% endif %}\r\n<div class=\"cat_back\">\r\n    <center><a href=\"{{SUBDIR}}{{get_cat_part_href(part_id)}}{{page}}\" class=\"btn btn-default\"> << Назад</a></center>\r\n</div>\r\n','<b>Просмотр отдельной позиции в каталоге</b>','','cat_item_view','twig'),(108,'cat_part_list',1,'<div id=\"cat_parts\">\r\n    {% for row in rows %}\r\n        <div class=\"cat_part\">\r\n            <div class=\"cat_part_image_border\">\r\n                <div class=\"cat_part_image_table\">\r\n                    <div class=\"cat_part_image\">\r\n                        {% set image = get_part_image_filename(row.image_name) %}\r\n                        {% if image %}\r\n                            <a href=\"{{ SUBDIR }}{{ get_cat_part_href(row.id) }}\" title=\"{{ row.title }}\">\r\n                                <img src=\"{{ SUBDIR }}{{ image }}\" alt=\"{{ row.title }}\" border=\"0\" align=\"left\">\r\n                            </a>\r\n                        {% else %}\r\n                            Изображение отсутствует\r\n                        {% endif %}\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"cat_part_title\">\r\n                <a href=\"{{ SUBDIR }}{{ get_cat_part_href(row.id) }}\" title=\"{{ row.title }}\">{{ row.title }}</a>\r\n            </div>\r\n        </div>       \r\n\r\n    {% endfor %}\r\n</div>\r\n','<b>Просмотр разделов в каталоге</b>','','cat_part_list','twig'),(110,'user_passwd_recovery_confirm',1,'<div class=\"center-block\" align=\"center\">\r\n<div align=\"center\" style=\"max-width: 400px;margin-top:30px;\">\r\n<form action=\"[%SUBDIR%]passwd_recovery/\" method=\"post\" name=\"passwd_change_form\">\r\n\r\n<input type=\"hidden\" name=\"passwd_change\" value=\"1\">\r\n<input type=\"hidden\" name=\"token\" value=\"[%token%]\">\r\n\r\n<input type=\"password\" name=\"new_passwd1\" class=\"form-control\" placeholder=\"Новый пароль\" required>\r\n<br />\r\n<input type=\"password\" name=\"new_passwd2\" class=\"form-control\" placeholder=\"Повтор нового пароля\" required>\r\n<br />\r\n<input type=\"submit\" class=\"btn btn-primary\" value=\"   Сменить   \">\r\n\r\n</form>\r\n</div>\r\n</div>','Форма смены пароля','','user_passwd_recovery_confirm','twig'),(109,'user_passwd_recovery',1,'<div class=\"center-block\" align=\"center\">\r\n<div align=\"center\" style=\"max-width: 400px;margin-top:30px;\">\r\n<form action=\"[%SUBDIR%]passwd_recovery/\" method=\"post\" name=\"passwd_change_form\">\r\n\r\n<input type=\"hidden\" name=\"passwd_recovery\" value=\"1\">\r\n\r\nУкажите почту, с который Вы регистрировались на сайте, и мы вышлем на неё инструкцию по восстановлению пароля.\r\n\r\n<input type=\"edit\" name=\"email\" class=\"form-control\" placeholder=\"Ваша почта\" required autofocus>\r\n<br />\r\n<input type=\"submit\" class=\"btn btn-primary\" value=\"   Отправить письмо   \">\r\n\r\n</form>\r\n</div>\r\n</div>','Форма восстановления пароля','','user_passwd_recovery','twig'),(111,'price_items',1,'<br />\r\n<table width=\"100%\" class=\"table table-striped table-responsive table-bordered normal-form\"\r\n<tr class=\"price_header\" valign=\"middle\">\r\n	<td width=\"30%\" class=\"price_header\">Наименование</td>\r\n	<td width=\"50%\" class=\"price_header\">Описание</td>\r\n	<td width=\"10%\" class=\"price_header\">Цена с НДС по безналичному расчету руб/час</td>\r\n</tr>\r\n[%loop_begin%]\r\n	<tr valign=\"middle\" class=\"price\"_line>\r\n	<td class=\"title\">[%row(title)%]</td>\r\n	<td class=\"title\">[%row(descr,nl2br)%]</td>\r\n	<td class=\"price\">[%row(price)%]</td>\r\n	</tr>\r\n[%loop_end%]\r\n</table>\r\n<br />','','','price_items','twig');
/*!40000 ALTER TABLE `templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `login` varchar(64) NOT NULL DEFAULT '-',
  `passwd` varchar(128) NOT NULL DEFAULT '-',
  `salt` varchar(32) NOT NULL DEFAULT '',
  `email` varchar(32) NOT NULL DEFAULT '',
  `fullname` varchar(254) NOT NULL DEFAULT '',
  `regdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `flags` varchar(255) NOT NULL DEFAULT '',
  `token` varchar(255) NOT NULL,
  `token_expire` int(11) NOT NULL,
  `avatar` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (7,'admin','$2a$13$QfyhnFoNSZacO9NccpTGwekohPG6aAW/EApdo6S7IvLj0ojNsEvIq','QfyhnFoNSZacO9NccpTGwp','boot@ngs.ru','Игорь Краснов','2013-04-03 16:42:31','active;admin;global;passwd','$2a$13$jxxtlMqxMhgHHGrub3nm0..97bld/hesplJdfAVccybnK36/BI83.',1619901415,'boot.jpg');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_flags`
--

DROP TABLE IF EXISTS `users_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_flags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_flags`
--

LOCK TABLES `users_flags` WRITE;
/*!40000 ALTER TABLE `users_flags` DISABLE KEYS */;
INSERT INTO `users_flags` VALUES (1,'Полный доступ','global',''),(2,'Авторизованный','active',''),(3,'Смена пароля','passwd',''),(4,'Админ','admin',''),(5,'Регистрация','signup','');
/*!40000 ALTER TABLE `users_flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitor_log`
--

DROP TABLE IF EXISTS `visitor_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visitor_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `day` varchar(16) DEFAULT NULL,
  `remote_addr` varchar(16) DEFAULT NULL,
  `remote_host` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `script_name` varchar(64) DEFAULT NULL,
  `request_uri` varchar(255) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `unique_visitor` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `day` (`day`),
  KEY `remote_addr` (`remote_addr`),
  KEY `remote_host` (`remote_host`),
  KEY `user_agent` (`user_agent`),
  KEY `script_name` (`script_name`),
  KEY `uid` (`uid`),
  KEY `unique_visitor` (`unique_visitor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor_log`
--

LOCK TABLES `visitor_log` WRITE;
/*!40000 ALTER TABLE `visitor_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `visitor_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-01  3:38:18
